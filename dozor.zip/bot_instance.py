from aiogram import Bot, Dispatcher
import config

bot = Bot(token=config.TELEGRAM_TOKEN)
dp = Dispatcher()
