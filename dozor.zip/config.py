TELEGRAM_TOKEN = "8263124097:AAHHzmhZkcKd_kX8h4hNiUkmbkG95C20sjI"
ADMINS = ["simsim_pro", "myoldtgid", "1Ilyakrut9"]  # список username админов без @

DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "dozor",          # либо твой пользователь из XAMPP
    "password": "79q9xIiG7bX6R[w2",          # если пароля нет — оставь пустым
    "database": "dozor"      # создаём заранее через phpMyAdmin
}


